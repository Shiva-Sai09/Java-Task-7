1. What is JDBC?
JDBC (Java Database Connectivity) is a Java API that allows Java programs to connect to and interact with relational databases like MySQL, PostgreSQL, and Oracle. It provides classes and interfaces to execute SQL queries and retrieve results.


2. What is PreparedStatement?
PreparedStatement is a JDBC interface used to execute precompiled SQL queries with placeholders (?). It improves performance, supports dynamic parameters, and helps prevent SQL injection.


3. Difference between Statement and PreparedStatement
Statement: Executes SQL queries as plain text. The query is compiled every time it runs.
PreparedStatement: Precompiles the SQL query and allows parameters (?). Faster for repeated queries and more secure.


4. How do you handle SQL exceptions?
By using try-catch blocks to catch SQLException and log error details.
Example:
try {
    // JDBC code
} catch (SQLException e) {
    e.printStackTrace();
}


5. How to prevent SQL Injection?
Always use PreparedStatement with ? placeholders instead of string concatenation.
Validate and sanitize user inputs before using them in queries.


6. What is JDBC DriverManager?
DriverManager is a class that manages JDBC drivers. It is used to establish a connection to the database:
Connection conn = DriverManager.getConnection(url, user, pass);


7. How to close connections?
Close all JDBC resources (ResultSet, Statement, Connection) in finally blocks or using try-with-resources:
try (Connection conn = ...; PreparedStatement ps = ...; ResultSet rs = ...) {
    // work
}


8. What is a ResultSet?
ResultSet is an object that stores the data retrieved from executing a SELECT query.
We can use methods like rs.next(), rs.getString(), etc., to access the rows.


9. What is auto-commit in JDBC?
By default, JDBC executes each SQL statement in its own transaction and commits automatically (auto-commit = true).
You can disable it to group multiple operations into one transaction:
conn.setAutoCommit(false);


10. How to connect Java to MySQL?
Steps:
Add MySQL JDBC Driver (mysql-connector-java.jar) to classpath.
Use Class.forName("com.mysql.cj.jdbc.Driver") (optional in newer versions).
Call:
Connection conn = DriverManager.getConnection(
    "jdbc:mysql://localhost:3306/dbname", "username", "password");